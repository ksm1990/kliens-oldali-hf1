import { useState } from "react";

const HouseholdSummary = () => {
  return <div></div>;
};

export default HouseholdSummary;
